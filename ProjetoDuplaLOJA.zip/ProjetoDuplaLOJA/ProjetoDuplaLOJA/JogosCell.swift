//
//  JogosCell.swift
//  ProjetoDuplaLOJA
//
//  Created by COTEMIG on 01/10/20.
//  Copyright © 2020 AndreHuberViniciusMartins. All rights reserved.
//

import UIKit

class JogosCell: UITableViewCell {

    @IBOutlet weak var NomeGame: UILabel!
    @IBOutlet weak var ImagemGame: UIImageView!
      @IBOutlet weak var PrecoGame: UILabel!
}
